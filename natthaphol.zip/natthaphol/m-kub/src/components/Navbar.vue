<template>
    <div>
        <nav class="navbar">
    <a href="index.html" class="active"> <i class="fas fa-user"></i> <span>Profile</span> </a>
    <a href="abilities.html"> <i class="fas fa-address-card"></i> <span>Abilities</span> </a>
    <a href="projects.html"> <i class="fas fa-briefcase"></i> <span>Project</span> </a>
    <a href="contact.html"> <i class="fas fa-address-book"></i> <span>contact</span> </a>
</nav>
    </div>
  
</template>

<script>
export default {

}
</script>

<style>

</style>