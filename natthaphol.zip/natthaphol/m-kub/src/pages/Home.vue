<template>
    <div>
       <navbar />
       <section class="home">
   
   <div class="image">
       <img src="images/profile.png" alt="">
   </div>
   
   <div class="content">
       <h3>I'm Natthaphol lapchai</h3>
       <span>"Live For Tomorrow."</span>
       <p>Hi, I am a student of the Faculty of Engineering. Multimedia and Entertainment 2nd year with skills in graphics, drawing, photography and music.</p>
       <a href="about.html" class="btn"> about me <i class="fas fa-user"></i> </a>
   </div>
   
   </section>
    </div>
   </template>
   
   <script>
   import Navbar from '../components/Navbar.vue';
   export default {
       components: { Navbar }
   }
   </script>
   
   <style>
   
   </style>